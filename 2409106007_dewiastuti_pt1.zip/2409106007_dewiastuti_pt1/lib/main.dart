import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// Widget MaterialApp sebagai wrapper utama aplikasi
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Widget MaterialApp
    return MaterialApp(
      title: 'CleanRide',
      debugShowCheckedModeBanner: false, // Menghilangkan banner debug
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const HomePage(), // Menentukan halaman utama
    );
  }
}

// Widget Stateful/Stateless untuk Halaman Home Page
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Widget Scaffold sebagai struktur dasar halaman
    return Scaffold(
      backgroundColor: Colors.grey.shade100, // Warna background
      // Widget SafeArea agar konten tidak tertutup notch/status bar
      body: SafeArea(
        // Widget SingleChildScrollView agar halaman dapat di-scroll
        child: SingleChildScrollView(
          // Widget Padding untuk memberikan jarak di sekeliling konten utama
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            // Widget Column untuk menyusun elemen secara vertikal
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Widget Row untuk menyusun header (Salam & Icon Notifikasi)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Widget Column untuk teks salam dan nama aplikasi
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Widget Text untuk salam
                        Text(
                          'Selamat Datang di',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),
                        // Widget SizedBox untuk memberi jarak vertikal
                        const SizedBox(height: 4),
                        // Widget Text untuk nama aplikasi
                        const Text(
                          'CleanRide App',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                    // Widget Container untuk pembungkus icon notifikasi
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      // Widget Icon untuk notifikasi
                      child: const Icon(
                        Icons.notifications_none,
                        color: Colors.black,
                        size: 24,
                      ),
                    ),
                  ],
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 20),

                // Widget TextField untuk kolom pencarian pencucian
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Cari layanan cuci mobil/motor...',
                    hintStyle: TextStyle(color: Colors.grey.shade400),
                    suffixIcon: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      // Widget Icon pencarian
                      child: Icon(
                        Icons.search,
                        size: 24,
                        color: Colors.grey.shade400,
                      ),
                    ),
                  ),
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 20),

                // Widget Text untuk judul seksi layanan
                const Text(
                  'Layanan Utama',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 12),

                // Card Layanan 1: Cuci Mobil Express
                // Widget Container sebagai card
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  // Widget Row untuk menyusun foto/ikona dan detail layanan
                  child: Row(
                    children: [
                      // Widget Container sebagai placeholder gambar layanan
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        // Widget Icon di dalam gambar
                        child: const Icon(
                          Icons.directions_car,
                          size: 40,
                          color: Colors.blue,
                        ),
                      ),
                      // Widget SizedBox untuk memberi jarak horizontal
                      const SizedBox(width: 12),
                      // Widget Expanded agar informasi mengisi sisa ruang
                      Expanded(
                        // Widget Column untuk informasi layanan
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Widget Text nama layanan
                            const Text(
                              'Cuci Mobil Express',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            // Widget Text deskripsi singkat
                            Text(
                              'Cuci luar & dalam (30 menit)',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            // Widget SizedBox untuk memberi jarak
                            const SizedBox(height: 8),
                            // Widget Text harga layanan
                            const Text(
                              'Rp50.000',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            // Widget SizedBox untuk memberi jarak
                            const SizedBox(height: 8),
                            // Widget Container sebagai tombol aksi
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.
                                circular(6),
                              ),
                              // Widget Row di dalam tombol
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  // Widget Icon pesan/pesan sekarang
                                  Icon(
                                    Icons.local_car_wash,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                  // Widget SizedBox jarak horizontal
                                  SizedBox(width: 6),
                                  // Widget Text tombol
                                  Text(
                                    'Pesan Layanan',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Widget SizedBox untuk memberi jarak antar card
                const SizedBox(height: 12),

                // Card Layanan 2: Cuci Motor Detailing
                // Widget Container sebagai card
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  // Widget Row
                  child: Row(
                    children: [
                      // Widget Container gambar/icon
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        // Widget Icon motor
                        child: const Icon(
                          Icons.two_wheeler,
                          size: 40,
                          color: Colors.blue,
                        ),
                      ),
                      // Widget SizedBox
                      const SizedBox(width: 12),
                      // Widget Expanded
                      Expanded(
                        // Widget Column
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Widget Text
                            const Text(
                              'Cuci Motor Detailing',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            // Widget Text
                            Text(
                              'Bersih mesin & semir ban',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            // Widget SizedBox
                            const SizedBox(height: 8),
                            // Widget Text
                            const Text(
                              'Rp25.000',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            // Widget SizedBox
                            const SizedBox(height: 8),
                            // Widget Container tombol
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              // Widget Row
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  // Widget Icon
                                  Icon(
                                    Icons.local_car_wash,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                  // Widget SizedBox
                                  SizedBox(width: 6),
                                  // Widget Text
                                  Text(
                                    'Pesan Layanan',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Widget SizedBox
                const SizedBox(height: 12),

                // Card Layanan 3: Hydrophobic Coating
                // Widget Container sebagai card
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  // Widget Row
                  child: Row(
                    children: [
                      // Widget Container
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        // Widget Icon
                        child: const Icon(
                          Icons.invert_colors,
                          size: 40,
                          color: Colors.blue,
                        ),
                      ),
                      // Widget SizedBox
                      const SizedBox(width: 12),
                      // Widget Expanded
                      Expanded(
                        // Widget Column
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Widget Text
                            const Text(
                              'Coating Anti Air',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            // Widget Text
                            Text(
                              'Perlindungan cat kilat tahan lama',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            // Widget SizedBox
                            const SizedBox(height: 8),
                            // Widget Text
                            const Text(
                              'Rp120.000',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                            // Widget SizedBox
                            const SizedBox(height: 8),
                            // Widget Container tombol
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 12),
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              // Widget Row
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  // Widget Icon
                                  Icon(
                                    Icons.local_car_wash,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                  // Widget SizedBox
                                  SizedBox(width: 6),
                                  // Widget Text
                                  Text(
                                    'Pesan Layanan',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

      // Widget bottomNavigationBar untuk navigasi bawah aplikasi
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            top: BorderSide(color: Colors.grey.shade300),
          ),
        ),
        // Widget Row untuk menyusun menu navigasi
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Widget Column untuk Menu Beranda
            Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                // Widget Icon
                Icon(Icons.home, color: Colors.blue),
                // Widget Text
                Text(
                  'Beranda',
                  style: TextStyle(fontSize: 12, color: Colors.blue),
                ),
              ],
            ),
            // Widget Column untuk Menu Pesanan
            Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                // Widget Icon
                Icon(Icons.history, color: Colors.grey),
                // Widget Text
                Text(
                  'Riwayat',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
            // Widget Column untuk Menu Profil
            Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                // Widget Icon
                Icon(Icons.person, color: Colors.grey),
                // Widget Text
                Text(
                  'Profil',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}