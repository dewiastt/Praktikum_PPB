import 'package:flutter/material.dart';
import 'cart_page.dart';

// Widget Stateful/Stateless untuk Halaman Home Page
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Widget Scaffold sebagai struktur dasar halaman
    return Scaffold(
      backgroundColor: Colors.grey.shade100, // Warna background
      // Widget SafeArea agar konten tidak tertutup notch/status bar
      body: SafeArea(
        // Widget SingleChildScrollView agar halaman dapat di-scroll
        child: SingleChildScrollView(
          // Widget Padding untuk memberikan jarak di sekeliling konten utama
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            // Widget Column untuk menyusun elemen secara vertikal
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Widget Row untuk menyusun header (Salam & Icon Notifikasi + Keranjang)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Widget Column untuk teks salam dan nama aplikasi
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Widget Text untuk salam
                        Text(
                          'Selamat Datang di',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),
                        // Widget SizedBox untuk memberi jarak vertikal
                        const SizedBox(height: 4),
                        // Widget Text untuk nama aplikasi
                        const Text(
                          'CleanRide App',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                    // Widget Row untuk menyusun icon notifikasi dan icon keranjang
                    Row(
                      children: [
                        // Widget Container untuk pembungkus icon notifikasi
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          // Widget Icon untuk notifikasi
                          child: const Icon(
                            Icons.notifications_none,
                            color: Colors.black,
                            size: 24,
                          ),
                        ),
                        // Widget SizedBox untuk memberi jarak horizontal
                        const SizedBox(width: 8),
                        // GestureDetector untuk mendeteksi tap pada icon keranjang
                        GestureDetector(
                          onTap: () {
                            // Navigator.push: membuka CartPage
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const CartPage(),
                              ),
                            );
                          },
                          // Widget Container untuk pembungkus icon keranjang
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            // Widget Icon untuk keranjang
                            child: const Icon(
                              Icons.shopping_cart_outlined,
                              color: Colors.blue,
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 20),

                // Widget TextField untuk kolom pencarian pencucian
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Cari layanan cuci mobil/motor...',
                    hintStyle: TextStyle(color: Colors.grey.shade400),
                    suffixIcon: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      // Widget Icon pencarian
                      child: Icon(
                        Icons.search,
                        size: 24,
                        color: Colors.grey.shade400,
                      ),
                    ),
                  ),
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 20),

                // Widget Text untuk judul seksi layanan
                const Text(
                  'Layanan Utama',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                // Widget SizedBox untuk memberi jarak
                const SizedBox(height: 12),

                // Card Layanan 1: Cuci Mobil Express
                _buildServiceCard(
                  context: context,
                  icon: Icons.directions_car,
                  name: 'Cuci Mobil Express',
                  description: 'Cuci luar & dalam (30 menit)',
                  price: 'Rp50.000',
                ),

                // Widget SizedBox untuk memberi jarak antar card
                const SizedBox(height: 12),

                // Card Layanan 2: Cuci Motor Detailing
                _buildServiceCard(
                  context: context,
                  icon: Icons.two_wheeler,
                  name: 'Cuci Motor Detailing',
                  description: 'Bersih mesin & semir ban',
                  price: 'Rp25.000',
                ),

                // Widget SizedBox
                const SizedBox(height: 12),

                // Card Layanan 3: Hydrophobic Coating
                _buildServiceCard(
                  context: context,
                  icon: Icons.invert_colors,
                  name: 'Coating Anti Air',
                  description: 'Perlindungan cat kilat tahan lama',
                  price: 'Rp120.000',
                ),
              ],
            ),
          ),
        ),
      ),

      // Widget bottomNavigationBar untuk navigasi bawah aplikasi
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            top: BorderSide(color: Colors.grey.shade300),
          ),
        ),
        // Widget Row untuk menyusun menu navigasi
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            // Widget Column untuk Menu Beranda
            Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.home, color: Colors.blue),
                Text(
                  'Beranda',
                  style: TextStyle(fontSize: 12, color: Colors.blue),
                ),
              ],
            ),
            // GestureDetector agar menu Keranjang bisa ditekan untuk membuka CartPage
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CartPage(),
                  ),
                );
              },
              // Widget Column untuk Menu Keranjang
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.shopping_cart, color: Colors.grey),
                  Text(
                    'Keranjang',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
            // Widget Column untuk Menu Profil
            Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.person, color: Colors.grey),
                Text(
                  'Profil',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Widget untuk satu card layanan pada HomePage
  Widget _buildServiceCard({
    required BuildContext context,
    required IconData icon,
    required String name,
    required String description,
    required String price,
  }) {
    // Widget Container sebagai card
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12),
        // Widget BoxShadow agar card terlihat lebih memiliki kedalaman
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade300,
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      // Widget Row untuk menyusun foto/ikon dan detail layanan
      child: Row(
        children: [
          // Widget Stack untuk menumpuk gambar layanan dan label "Promo"
          Stack(
            children: [
              // Widget Container sebagai placeholder gambar layanan
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(8),
                ),
                // Widget Icon di dalam gambar
                child: Icon(
                  icon,
                  size: 40,
                  color: Colors.blue,
                ),
              ),
              // Widget Positioned untuk menempatkan label "Promo" di pojok kanan atas
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text(
                    'Promo',
                    style: TextStyle(fontSize: 8, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
          // Widget SizedBox untuk memberi jarak horizontal
          const SizedBox(width: 12),
          // Widget Expanded agar informasi mengisi sisa ruang
          Expanded(
            // Widget Column untuk informasi layanan
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  price,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 8),
                // GestureDetector agar tombol "Pesan Layanan" bisa memicu navigasi
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CartPage(),
                      ),
                    );
                  },
                  // Widget Container sebagai tombol aksi
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.local_car_wash,
                          size: 16,
                          color: Colors.white,
                        ),
                        SizedBox(width: 6),
                        Text(
                          'Pesan Layanan',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}