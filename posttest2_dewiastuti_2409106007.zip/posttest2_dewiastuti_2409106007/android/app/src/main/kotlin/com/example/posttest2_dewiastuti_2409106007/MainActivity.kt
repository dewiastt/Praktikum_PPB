package com.example.posttest2_dewiastuti_2409106007

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
