// Model data untuk satu item di keranjang
class CartItem {
  final String imagePath;
  final String name;
  final String description;
  final int price; // harga dalam angka, agar bisa dihitung
  int quantity;

  CartItem({
    required this.imagePath,
    required this.name,
    required this.description,
    required this.price,
    this.quantity = 1,
  });
}

// Fungsi bantu untuk format angka jadi "Rp10.000"
String formatRupiah(int number) {
  final str = number.toString();
  final buffer = StringBuffer();
  for (int i = 0; i < str.length; i++) {
    final posFromRight = str.length - i;
    buffer.write(str[i]);
    if (posFromRight > 1 && posFromRight % 3 == 1) {
      buffer.write('.');
    }
  }
  return 'Rp$buffer';
}