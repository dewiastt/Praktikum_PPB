import 'package:flutter/material.dart';
import 'cartitem.dart';

// ============================================================
// HALAMAN KONFIRMASI PESANAN BERHASIL
// ============================================================
class OrderSuccessPage extends StatelessWidget {
  final List<CartItem> items;
  final int total;

  const OrderSuccessPage({
    super.key,
    required this.items,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    // Widget Scaffold sebagai struktur dasar halaman konfirmasi
    return Scaffold(
      backgroundColor: Colors.white,
      // Widget SafeArea agar konten tidak tertutup notch/status bar
      body: SafeArea(
        // Widget SingleChildScrollView agar halaman dapat di-scroll
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                // Widget Icon centang besar sebagai indikator berhasil
                const Icon(
                  Icons.check_circle,
                  color: Colors.blue,
                  size: 64,
                ),
                const SizedBox(height: 12),
                const Text(
                  'Pesanan Berhasil!',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Terima kasih, pesanan kamu sedang diproses.',
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),

                const SizedBox(height: 20),

                // Widget Text judul ringkasan pesanan
                const Text(
                  'Ringkasan Pesanan',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                // Widget Container untuk daftar ringkasan item
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                    // Widget BoxShadow agar card ringkasan terlihat berdimensi
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.shade300,
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      for (final item in items)
                      // Widget Padding untuk memberi jarak antar baris ringkasan
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${item.name} x${item.quantity}',
                                style: const TextStyle(fontSize: 12),
                              ),
                              Text(
                                formatRupiah(item.price * item.quantity),
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      const SizedBox(height: 8),
                      // Widget Row untuk baris total pembayaran
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Total Bayar',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            formatRupiah(total),
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // GestureDetector agar tombol kembali ke beranda bisa ditekan
                GestureDetector(
                  onTap: () {
                    // Navigator.popUntil: kembali ke halaman paling awal (HomePage)
                    Navigator.popUntil(context, (route) => route.isFirst);
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Kembali ke Beranda',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}