import 'package:flutter/material.dart';
import 'home_page.dart';

void main() {
  runApp(const MyApp());
}

// Widget MaterialApp sebagai wrapper utama aplikasi
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Widget MaterialApp
    return MaterialApp(
      title: 'CleanRide',
      debugShowCheckedModeBanner: false, // Menghilangkan banner debug
      theme: ThemeData(
        fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      home: const HomePage(), // Menentukan halaman utama
    );
  }
}